/*
    Library class definition file
    library.cpp

    This file contains the implementation of the Library class methods
*/
#include <iostream>
#include <algorithm>
#include <fstream>
#include <sstream>
#include "library.h"
using namespace std;

// ------------- Main Methods --------------

// Method to add a new book to the library
bool Library::addBook(Book& newBook)
{
    // Error checks
    int errorCheck = 0;
    if (searchBookByID(newBook.getBookID()) != nullptr)
    {
        cerr << "Error: Book with ID: " << newBook.getBookID() << " already exists." << endl;
        errorCheck++;
    }
    if (searchBookByTitle(newBook.getTitle()) != nullptr)
    {
        cerr << "Error: Book with Title: \"" << newBook.getTitle() << "\" already exists." << endl;
        errorCheck++;
    }
    if (newBook.getBookID() <= 0)
    {
        cerr << "Error: Book ID must be a positive integer greater than zero." << endl;
        errorCheck++;
    }
    if (newBook.getPageCount() <= 0)
    {
        cerr << "Error: Page Count must be a positive integer greater than zero." << endl;
        errorCheck++;
    }
    if (newBook.getTitle() == "")
    {
        cerr << "Error: Title cannot be empty." << endl;
        errorCheck++;
    }
    if (newBook.getGenre() == "")
    {
        cerr << "Error: Genre cannot be empty." << endl;
        errorCheck++;
    }
    if (newBook.getAuthor() == "")
    {
        cerr << "Error: Author cannot be empty." << endl;
        errorCheck++;
    }
    if (errorCheck > 0)
    {
        return false;
    }

    bookCollection.push_back(newBook);
    return true;
}

// Method to remove a book from the library by its ID
void Library::removeBook(int bookID)
{
    // Error checks
    int errorCheck = 0;
    if (searchBookByID(bookID) == nullptr)
    {
        cerr << "Error: Book with ID: " << bookID << " not found." << endl;
        errorCheck++;
    }
    if (bookID <= 0)
    {
        cerr << "Error: Book ID must be a positive integer greater than zero." << endl;
        errorCheck++;
    }
    if (errorCheck > 0)
    {
        return;
    }

    // Iterates through the book collection vector to find the book with the given bookID
    for (auto it = bookCollection.begin(); it != bookCollection.end();)
    {
        if (it->getBookID() == bookID)
        {
            it = bookCollection.erase(it); // Removes the book from the vector without invalidating the iterator
            break;
        }
        else
        {
            ++it;
        }
    }
}

// Method to add a new member to the library
void Library::addMember(Member& newMember)
{
    // Error checks
    int errorCheck = 0;
    if (searchMemberByID(newMember.getMemberID()) != nullptr)
    {
        cerr << "Error: Member with ID: " << newMember.getMemberID() << " already exists." << endl;
        errorCheck++;
    }
    if (newMember.getMemberID() <= 0)
    {
        cerr << "Error: Member ID must be a positive integer greater than zero." << endl;
        errorCheck++;
    }
    if (newMember.getName() == "")
    {
        cerr << "Error: Member name cannot be empty." << endl;
        errorCheck++;
    }
    if (errorCheck > 0)
    {
        return;
    }

    memberList.push_back(newMember);
}

// Method to remove a member from the library by their ID
void Library::removeMember(int memberID)
{
    // Error check
    if (searchMemberByID(memberID) == nullptr)
    {
        cerr << "Error: Member with ID: " << memberID << " not found." << endl;
        return;
    }

    // Iterates through the member list vector to find the member with the given memberID
    for (auto it = memberList.begin(); it != memberList.end();)
    {
        if (it->getMemberID() == memberID)
        {
            it = memberList.erase(it); // Removes the member from the vector without invalidating the iterator
            break;
        }
        else
        {
            ++it;
        }
    }
}

// -------------- Transaction Methods --------------

// Method to borrow a book for a member
bool Library::borrowBook(int memberID, int bookID)
{
    // Error check
    if (memberID <= 0 || bookID <= 0)
    {
        cout << "Error: ID must be positive." << endl;
        return false; 
    }

    // Searches for the member and book objects from the library vectors and stores them into pointers
    Member *borrowingMember = searchMemberByID(memberID);
    Book *bookToBorrow = searchBookByID(bookID);

    if (bookToBorrow == nullptr || borrowingMember == nullptr)
    {
        cout << "Either the book or member was not found." << endl;
        return false; 
    }
    else if (bookToBorrow->getAvailability() == false)
    {
        cout << "Book ID " << bookID << " is not available for borrowing." << endl;
        return false; 
    }

    bookToBorrow->setAvailability(false); // Book object in the library is now marked as not available
    borrowingMember->borrowBookForMemberVector(*bookToBorrow); // Adds the book to the member's borrowedBooks vector
    return true;
}

// Method to return a book for a member
bool Library::returnBook(int memberID, int bookID)
{
    // Error check
    if (memberID <= 0 || bookID <= 0)
    {
        cout << "Error: Member ID and Book ID must be a positive integer greater than zero." << endl;
        return false; 
    }

    // Searches for the member and book objects from the library vectors and stores them into pointers
    Member *returningMember = searchMemberByID(memberID);
    Book *bookToReturn = searchBookByID(bookID);

    if (bookToReturn == nullptr || returningMember == nullptr)
    {
        cout << "Either the book or member was not found." << endl;
        return false; 
    }

    bookToReturn->setAvailability(true); // Book object in the library is now marked as available
    returningMember->returnBookForMemberVector(bookID); // Removes the book from the member's borrowedBooks vector
    return true;
}    

// -------------- Search Methods --------------

// Method to search for a book by its title
Book* Library::searchBookByTitle(const string& title)
{
    for (size_t i = 0; i < bookCollection.size(); ++i)
    {
        if (bookCollection[i].getTitle() == title)
        {
            return &bookCollection[i];
        }
    }
    return nullptr; // Not found
}

// Method to search for a book by its ID
Book* Library::searchBookByID(int bookID)
{   
    for (size_t i = 0; i < bookCollection.size(); ++i)
    {
        if (bookCollection[i].getBookID() == bookID)
        {
            return &bookCollection[i];
        }
    }
    return nullptr; // Not found
}

// Method to search for a member by their ID
Member* Library::searchMemberByID(int memberID)
{
    for (size_t i = 0; i < memberList.size(); ++i)
    {
        if (memberList[i].getMemberID() == memberID)
        {
            return &memberList[i];
        }
    }
    return nullptr; // Not found
}

// -------------- Display Methods --------------

// Method to display all available books in the library
void Library::displayAllAvailableBooks()
{
    cout << "\n--- Available Books ---" << endl;
    for (Book& book : bookCollection) // Iterate by const reference (no copies, read-only)
    {
        if (book.getAvailability())
        {
            book.displayBook();
            cout << "----------------------" << endl;
        }
    }
}

// Method to display all members of the library
void Library::displayAllMembers()
{
    cout << "\n--- Library Members ---" << endl;
    for (Member& member : memberList) // Iterate by const reference (no copies, read-only)
    {
        member.displayMemberDetails();
        cout << "----------------------" << endl;
    }
}

// -------------- Save and Load Methods --------------

// Method to save library data to files
bool Library::saveLibraryData(string bookFilename, string memberFilename)
{
    // Will save data into these two files
    ofstream writerBook(bookFilename);
    ofstream writerMember(memberFilename);

    // Checks if files can be opened
    if (!writerBook || !writerMember)
    {
        cerr << "Error: Could not open file for writing." << endl;
        return false;
    }

    // Saving Book Data
    for (Book& book : bookCollection)
    {
        writerBook << book.getBookID() << " " 
                   << "\"" << book.getTitle() << "\" " // Using "\"" to handle titles, authors and genres with spaces e.g "Harry Potter""
                   << "\"" << book.getAuthor() << "\" " 
                   << "\"" << book.getGenre() << "\" "
                   << book.getPageCount() << " " 
                   << book.getAvailability() << "\n";
    }

    // Saving Member Data
    for (Member& member : memberList)
    {
        writerMember << member.getMemberID() << " " 
                   << "\"" << member.getName() << "\" ";
                   // For loop to traverse through the borrowed books vector
                   for (Book& borrowedBook : member.getBorrowedBooks())
                   {
                        writerMember << borrowedBook.getBookID() << " ";
                   }
                   writerMember << "\n"; // Creates a new line after each member's data
    }

    // Closing the writers as saving process is finished
    writerBook.close();
    writerMember.close();
    return true;
}

// Method to load library data from files
bool Library::loadLibraryData(string bookFilename, string memberFilename)
{
    // Will load data from these two files
    ifstream readerBook(bookFilename);
    ifstream readerMember(memberFilename);
    string line;

    // Checks if files can be opened
    if (!readerBook || !readerMember)
    {
        cerr << "Error opening file" << endl;
        return false;
    }

    // Clears existing data
    bookCollection.clear();
    memberList.clear();

    // Loading Book Data
    while (getline(readerBook, line))
    {
        if (line.empty()) 
        {
            continue;
        }

        stringstream ss(line);
        int id, pageCount;
        string title, author, genre;
        bool available;

        ss >> id; // reads book ID
        ss.ignore(1, ' '); // ignore space after ID

        ss.ignore(1, '"'); // ignore opening quote for title
        getline(ss, title, '"'); // reads title up to closing quote
        ss.ignore(1, ' '); // ignore open space

        ss.ignore(1, '"'); // ignore opening quote for author
        getline(ss, author, '"'); // reads author up to closing quote
        ss.ignore(1, ' '); // ignore open space

        ss.ignore(1, '"'); // ignore opening quote for genre
        getline(ss, genre, '"'); // reads genre up to closing quote
        ss.ignore(1, ' '); // ignore open space

        ss >> pageCount >> available; // reads page count and availability

        // Create Book object and add to collection
        Book loadedBook(id, title, author, genre, pageCount, available);
        bookCollection.push_back(loadedBook);
    }

    // Loading Member Data
    while (getline(readerMember, line))
    {
        if (line.empty()) 
        {
            continue;
        }

        stringstream ss(line);
        int memberID;
        string memberName;

        ss >> memberID; // reads ID

        ss.ignore(1, ' '); // ignore space after ID
        ss.ignore(1, '"'); // ignore opening quote for name
        getline(ss, memberName, '"'); // read name up to closing quote

        // Creates Member object
        Member loadedMember(memberID, memberName);

        int borrowedBookID;
        while (ss >> borrowedBookID)
        {
            // Finds the actual book object in the bookcollection
            Book* borrowedBookPtr = searchBookByID(borrowedBookID);
            if (borrowedBookPtr != nullptr)
            {
                // Member class will store a copy of the book object
                loadedMember.borrowBookForMemberVector(*borrowedBookPtr);
            }
            else
            {
                cerr << "Error: Book ID " << borrowedBookID << " not found" << endl;
            }
        }
        memberList.push_back(loadedMember);
    }

    readerBook.close();
    readerMember.close();
    cout << "Library Data loaded successfully" << endl;
    return true;
}