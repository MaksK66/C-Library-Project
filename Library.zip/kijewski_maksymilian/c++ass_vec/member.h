/*
    Member Class Declaration file
    member.h

    This file contains the declaration of the Member class and its methods, representing a library member
*/
#ifndef member_h
#define member_h
#include <vector>
#include "book.h"
using namespace std;

class Member
{
    // Private Member variables
    private:
        int memberID;
        string name;
        vector <Book> borrowedBooks;
        
    public:
        // Constructor to initialize a Member object
        Member(int id, string n);

        // Copy constructor for the Member class
        Member(const Member& other);

        // Getter methods for the Member class
        int getMemberID() const;
        string getName() const;
        vector<Book> getBorrowedBooks() const;

        // Setter methods for the Member class
        void setMemberID(int id);
        void setName(string n);

        // Methods to manage borrowed books
        void borrowBookForMemberVector(Book& book); 
        void returnBookForMemberVector(int bookID);

        // Methods to display Member details and borrowed books
        void displayBorrowedBooks();
        void displayMemberDetails();
};
#endif