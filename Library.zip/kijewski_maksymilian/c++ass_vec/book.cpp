/*
    Book class defintion file
    book.cpp

    This file contains the implementation of the Book class methods
*/
#include <iostream>
#include <string>
#include "book.h"
using namespace std;

// Definition of the Book class constructor
Book::Book(int id, string t, string a, string g, int pCount, bool available) 
{
    bookID = id;
    title = t;
    author = a;
    genre = g;
    pageCount = pCount;
    isAvailable = available;
}
// Definition of the Book class copy constructor
Book::Book(const Book& other) 
{
    bookID = other.bookID;
    title = other.title;
    author = other.author;
    genre = other.genre;
    pageCount = other.pageCount;
    isAvailable = other.isAvailable;
}

// Definition of the Book class getter methods
int Book::getBookID () const
{
    return bookID;
}
string Book::getTitle() const
{
    return title;
}
string Book::getAuthor() const
{
    return author;
}
string Book::getGenre() const
{
    return genre;
}
int Book::getPageCount() const
{
    return pageCount;
}
bool Book::getAvailability() const
{
    return isAvailable;
}
// Definition of the Book class setter methods
void Book::setBookID(int id) 
{
    bookID = id;
}
void Book::setTitle(string t) 
{
    title = t;
}
void Book::setAuthor(string a) 
{
    author = a;
}
void Book::setGenre(string g) 
{
    genre = g;
}
void Book::setPageCount(int pCount) 
{
    pageCount = pCount;
}
void Book::setAvailability(bool available) 
{
    isAvailable = available;
}

// Definition of the Book class method to display book details
void Book::displayBook() const
{
    cout << "Book ID: " << bookID << endl;
    cout << "Title: " << title << endl;
    cout << "Author: " << author << endl;
    cout << "Genre: " << genre << endl;
    cout << "Page Count: " << pageCount << endl;
    cout << "Availability: " << (isAvailable ? "Available" : "Not Available") << endl;
}