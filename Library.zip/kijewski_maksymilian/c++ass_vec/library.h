/*
    Library class Declaration file
    library.h

    This file contains the declaration of the Library class and its methods, representing a library which manages books and its registered members
*/
#ifndef library_h
#define library_h
#include <vector>
#include "book.h"
#include "member.h"
using namespace std;

class Library
{
    // Private member variables
    private:
        vector<Book> bookCollection;
        vector<Member> memberList;
    
    public:
        // Core methods for Library management
        bool addBook(Book& newBook);
        void removeBook(int bookID);
        void addMember(Member& newMember);
        void removeMember(int memberID);

        // Transaction methods
        bool borrowBook(int memberID, int bookID);
        bool returnBook(int memberID, int bookID);

        // Search methods
        Book* searchBookByTitle(const string& title);
        Book* searchBookByID(int bookID);
        Member* searchMemberByID(int memberID);

        // Display methods
        void displayAllAvailableBooks();
        void displayAllMembers();

        // Save and Load methods
        bool saveLibraryData(string bookFilename = "book.txt", string memberFilename = "member.txt");
        bool loadLibraryData(string bookFilename = "book.txt", string memberFilename = "member.txt");
};
#endif