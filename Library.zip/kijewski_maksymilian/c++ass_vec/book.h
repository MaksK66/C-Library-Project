/*
    Book class Declaration file
    book.h

    This file contains the declaration of the Book class and its methods, representing a book object in a library system
*/
#ifndef book_h
#define book_h
using namespace std;

class Book 
{
    // Private member variables
    private:
        int bookID; 
        string title;
        string author;
        string genre;
        int pageCount;
        bool isAvailable;
    
    public:
        // Constructor to initialize a Book object
        Book(int id, string t, string a, string g, int pCount, bool available);

        // Copy constructor for the Book class
        Book(const Book& other);

        // Getter methods for the Book class
        int getBookID() const;
        string getTitle() const;
        string getAuthor() const;
        string getGenre() const;
        int getPageCount() const;
        bool getAvailability() const;

        // Setter methods for the Book class
        void setBookID(int id);
        void setTitle(string t);
        void setAuthor(string a);
        void setGenre(string g);
        void setPageCount(int pCount);
        void setAvailability(bool available);

        // Method to display Book details
        void displayBook() const;
};
#endif