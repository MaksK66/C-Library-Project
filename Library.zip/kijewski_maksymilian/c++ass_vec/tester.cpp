/*
    tester.cpp
    Comprehensive test file for the vector-based Library system, 
    Containing a menu that allows a user to run their own test scenarios,
    a test from the assignment brief, and my own personal test
*/
#include <iostream>
#include <string>
#include "book.h"
#include "member.h"
#include "library.h"
using namespace std;

// Forward declaration of a helper method to test the loading process for my personal tests
void run_load_test();
// Forward declaration of menu function 
void menu();
// Forward declaration of runBriefTest function
void runBriefTest();
// Forward declaration of runPersonalTest function
void runPersonalTest();

// Main function to start the program
int main() 
{
    menu(); 
    return 0;
}

// My own personal scripted test run function that covers various scenarios
void runPersonalTest()
{
    cout << "\n===================================" << endl;
    cout << "PERSONAL TESTS" << endl;
    cout << "===================================" << endl;
    
    // --- 1. Initialize and Setup Data ---
    Library myLibrary; 
    cout << "\n===================================" << endl;
    cout << "A) INITIAL SETUP & VALIDATION" << endl;
    cout << "===================================" << endl;
    
    // Add Books
    cout << "--- Initializing Books ---" << endl;
    Book book1(101, "BOOK1", "Maks Kijewski", "Sci-Fi", 384, true);
    Book book2(102, "BOOK2", "Dundee University", "Horror", 328, true);
    Book book3(103, "BOOK3", ":)", "Action", 412, true);

    myLibrary.addBook(book1);
    myLibrary.addBook(book2);
    myLibrary.addBook(book3);
    
    // Test duplicate add by ID (should fail)
    Book book4_duplicate(103, "BOOK4", ":(", "Comedy", 412, true);
    // Expected Error: Book 103 already exists
    if (!myLibrary.addBook(book4_duplicate))
    {
        cout << "SUCCESS: Duplicate book addition blocked." << endl;
    }   
    // Test duplicate add by Title (should fail)
    Book book5_duplicate(104, "BOOK2", "My cat", "Drama", 300, true);
    // Expected Error: Book "BOOK2" already exists
    if (!myLibrary.addBook(book5_duplicate))
    {
        cout << "SUCCESS: Duplicate book addition blocked." << endl;
    }

    // Add Members
    cout << "\n--- Initializing Members ---" << endl;
    Member memberA(1, "Jane Doe");
    Member memberB(2, "John Doe");
    
    myLibrary.addMember(memberA);
    myLibrary.addMember(memberB);

    // Initial State Check
    cout << "\n--- Initial Available Books ---" << endl;
    myLibrary.displayAllAvailableBooks(); 
    cout << "\n--- Initial Members ---" << endl;
    myLibrary.displayAllMembers(); 
    
    // ----------------------------------------------------
    // 2. Transaction Tests (Borrow, Double Borrow, Return)
    // ----------------------------------------------------

    cout << "\n===================================" << endl;
    cout << "B) TRANSACTION TESTS" << endl;
    cout << "===================================" << endl;

    // Borrow 101 (Jane)
    if (myLibrary.borrowBook(1, 101)) 
    {
        cout << "SUCCESS: Jane borrowed BOOK1 (101)." << endl;
    } 

    // Borrow 102 (John)
    if (myLibrary.borrowBook(2, 102)) 
    {
        cout << "SUCCESS: John borrowed BOOK2 (102)." << endl;
    } 

    // Attempt double borrow (should fail)
    cout << "\n--- Attempting double borrow (John 101) ---" << endl;
    if (!myLibrary.borrowBook(2, 101)) 
    {
        cout << "SUCCESS: Blocked double borrow of BOOK1 (101)." << endl;
    }

    // Attempt invalid borrow (non-existent ID)
    cout << "\n--- Attempting invalid borrow (ID 999) ---" << endl;
    if (!myLibrary.borrowBook(1, 999)) 
    {
        cout << "SUCCESS: Blocked borrow of non-existent book (999)." << endl;
    }
    
    // Final State After Borrow
    cout << "\n--- Final State (After Borrows) ---" << endl;
    myLibrary.displayAllMembers(); 

    // Return 101 (Jane)
    cout << "\n--- Performing Return Transaction ---" << endl;
    if (myLibrary.returnBook(1, 101)) 
    {
        cout << "SUCCESS: Jane returned BOOK1 (101)." << endl;
    }

    // Final State After Return
    cout << "\n--- State After Return (101) ---" << endl;
    myLibrary.displayAllAvailableBooks(); // 101 should be back
    myLibrary.displayAllMembers();        // Jane should have no books
    
    // ----------------------------------------------------
    // 3. Search and Remove Tests
    // ----------------------------------------------------
    
    cout << "\n===================================" << endl;
    cout << "C) SEARCH & REMOVE TESTS" << endl;
    cout << "===================================" << endl;
    
    // Search by Title
    cout << "\n--- Search for 'BOOK1' by Title ---" << endl;
    Book* searchTitle = myLibrary.searchBookByTitle("BOOK1");
    if (searchTitle != nullptr) 
    {
        cout << "SUCCESS: Found Book by Title: " << endl;
        searchTitle->displayBook(); 
    }

    // Search Member by ID and display their borrowed books
    cout << "\n--- Display John Doe (ID 2) Borrowed Books via Search ---" << endl;
    Member* JohnPtr = myLibrary.searchMemberByID(2); 
    if (JohnPtr != nullptr) 
    {
        JohnPtr->displayBorrowedBooks(); 
    }

    // Remove Book 103 (BOOK3)
    cout << "\n--- Removing Book 103 (BOOK3) ---" << endl;
    myLibrary.removeBook(103);
    
    // Check if removal worked (search should fail)
    if (myLibrary.searchBookByID(103) == nullptr) 
    {
        cout << "SUCCESS: Book 103 successfully removed." << endl;
    }

    // ----------------------------------------------------
    // 4. File I/O Tests (Save and Load)
    // ----------------------------------------------------
    
    cout << "\n===================================" << endl;
    cout << "D) FILE I/O TESTS" << endl;
    cout << "===================================" << endl;
    
    // Save the current state (Books: 101, 102; Members: 1, 2 (John has 102))
    cout << "\n--- Saving Data to Files ---" << endl;
    myLibrary.saveLibraryData("personal_book.txt", "personal_member.txt"); 
    cout << "Library state saved to personal_book.txt and personal_member.txt." << endl;
    
    // Run the load test in a separate scope/function
    run_load_test(); 
    
    cout << "\nPersonal Tests Complete." << endl;
}
//                                                  ^
//                                                  |
// Helper function to test loading the saved data ---
// from the output files created in the personal tests
void run_load_test()
{
    cout << "\n===================================" << endl;
    cout << "E) DATA LOAD TEST (New Library)" << endl;
    cout << "===================================" << endl;
    
    Library loadedLibrary;
    loadedLibrary.loadLibraryData("personal_book.txt", "personal_member.txt");
    
    cout << "\n--- Available Books in Loaded Library ---" << endl;
    // Expected: Book 101 (Available), Book 102 (Unavailable)
    loadedLibrary.displayAllAvailableBooks(); 

    cout << "\n--- Members in Loaded Library ---" << endl;
    // Expected: Jane (No books), John (Has Book 102)
    loadedLibrary.displayAllMembers();
    
    // Verify John's book ID 102 is present
    Member* JohnLoadedPtr = loadedLibrary.searchMemberByID(2);
    if (JohnLoadedPtr != nullptr) 
    {
        JohnLoadedPtr->displayBorrowedBooks();
    }
    
    cout << "\nLoad Test Complete." << endl;
}

// The scripted test from the assignment brief
void runBriefTest()
{
    cout << "\n===================================" << endl;
    cout << "BRIEF ASSIGNMENT TESTS" << endl;
    cout << "===================================" << endl;

    Library myLibrary;

    // --- SCENARIO 1: Load the sample data files ---
    cout << "\n--- 1. Loading Sample Data (book_brief.txt & member_brief.txt) [SHOULD PARTIALLY SUCCEED]---" << endl;
    myLibrary.loadLibraryData("book_brief.txt", "member_brief.txt");
    
    cout << "\nInitial State after Load:" << endl;
    myLibrary.displayAllAvailableBooks();
    myLibrary.displayAllMembers();
    
    // --- SCENARIO 2: Add a new book (Using ID 110) ---
    cout << "\n--- 2. Adding New Book (ID 110: 'The Power of Positive Thinking') [SHOULD FAIL]---" << endl;
    int newBookID = 110;
    Book newBook(newBookID, 
                 "The Power of Positive Thinking", 
                 "Norman Vincent Peale", 
                 "Motivational, Spiritual", 
                 240, 
                 true);
    if (!myLibrary.addBook(newBook)) 
    {
        cout << "SUCCESS: Could not add Book ID 110 (This book already exists under ID 101)." << endl;
    }
    myLibrary.displayAllAvailableBooks();
    
    // --- SCENARIO 3: Add a new member named “Jane” (Using ID 110) ---
    cout << "\n--- 3. Adding New Member (ID 110: 'Jane') [SHOULD SUCCEED]---" << endl;
    int newMemberID = 110;
    Member newMember(newMemberID, "Jane");
    myLibrary.addMember(newMember);
    cout << "Member 'Jane' (ID 110) added." << endl;

    // --- SCENARIO 4: Have existing member 'Ben' borrow the book with ID "106" (ID 106) ---
    int benID = 106; 
    int bookID_106 = 106; 
    
    cout << "\n--- 4. Member ID " << benID << " (Ben) borrows Book ID " << bookID_106 << " [SHOULD FAIL]---" << endl;
    cout << "Book ID 106 exists in the loaded data and Ben already borrowed it so this should fail" << endl;
    if (myLibrary.borrowBook(benID, bookID_106))
    {
        cout << "SUCCESS: Member " << benID << " borrowed Book " << bookID_106 << "." << endl;
    } 
    else 
    {
        cout << "FAILURE: Borrow transaction failed (Book 106 may not exist/be available)." << endl;
    }

    // --- SCENARIO 5: Have the same member 'Ben' return the book with ID "106" (ID 106) ---
    cout << "\n--- 5. Member ID " << benID << " (Ben) returns Book ID " << bookID_106 << " [SHOULD SUCCEED]---" << endl;
    if (myLibrary.returnBook(benID, bookID_106)) 
    {
        cout << "SUCCESS: Member " << benID << " returned Book " << bookID_106 << "." << endl;
    } 
    else 
    {
        cout << "FAILURE: Return transaction failed (Book may not have been borrowed)." << endl;
    }

    // --- SCENARIO 6: Search for book with title "Awaken the Giant Within" ---
    string searchTitle = "Awaken the Giant Within";
    cout << "\n--- 6. Searching for Book: '" << searchTitle << "' [SHOULD SUCCEED]---" << endl;
    Book* foundBook = myLibrary.searchBookByTitle(searchTitle);
    
    if (foundBook != nullptr) 
    {
        cout << "SUCCESS: Found Book by Title: " << endl;
        foundBook->displayBook();
    } 
    else 
    {
        cout << "Book '" << searchTitle << "' not found." << endl;
    }

    // --- SCENARIO 7: Have existing member 'Chen' (ID 109) borrow the book with ID "109" (ID 109) ---
    // Book ID 109 doesnt exist in the loaded data, so this should fail
    int chenID = 109; 
    int bookID_109 = 109; 
    
    cout << "\n--- 7. Member ID " << chenID << " (Chen) borrows Book ID " << bookID_109 << " [SHOULD FAIL]---" << endl;
    if (myLibrary.borrowBook(chenID, bookID_109)) 
    {
        cout << "SUCCESS: Member " << chenID << " borrowed Book " << bookID_109 << "." << endl;
    } 
    else 
    {
        cout << "FAILURE: Could not complete borrow transaction (Book 109 may not exist/be available)." << endl;
    }

    // --- SCENARIO 8: Export the current data to new files (members_updated.txt and books_updated.txt) ---
    cout << "\n--- 8. Exporting Current Data to Updated Files ---" << endl;
    myLibrary.saveLibraryData("books_updated.txt", "members_updated.txt"); 
    cout << "Data exported successfully to books_updated.txt and members_updated.txt." << endl;
    myLibrary.loadLibraryData("books_updated.txt", "members_updated.txt");
    myLibrary.displayAllAvailableBooks();
    cout << "Books 106 and 104 are the same as there is no way check for the same title when loading from a file made outside the system." << endl;
    myLibrary.displayAllMembers();

    cout << "\nBrief Assignment Tests Complete." << endl;
}

// Menu function to allow user-driven testing alongside scripted tests
void menu()
{
    int choice;
    bool success;
    Library myLibrary;
    int id, memberID, bookID, pageCount;
    string name, title, author, genre, filenameB, filenameM;
    do {
    cout << "\nLibrary Management System Menu:" << endl;
    cout << "1. Add Book" << endl;
    cout << "2. Remove Book" << endl;
    cout << "3. Add Member" << endl;
    cout << "4. Remove Member" << endl;
    cout << "5. Borrow Book" << endl;
    cout << "6. Return Book" << endl;
    cout << "7. Search Book by Title" << endl;
    cout << "8. Search Book by ID" << endl;
    cout << "9. Search Member by ID (Will display their books)" << endl;
    cout << "10. Display All Available Books" << endl;
    cout << "11. Display All Members" << endl;
    cout << "12. Save Library Data" << endl;
    cout << "13. Load Library Data" << endl;
    cout << "14. Assignment Brief Test" << endl;
    cout << "15. Personal Test" << endl;
    cout << "16. Exit" << endl;
    cout << "Please enter your choice (1-16): ";
    cin >> choice;
    switch (choice)
    {
        case 1: // Add Book
            cout << "Enter Book ID: ";
            cin >> id;
            cin.ignore(10000, '\n'); 
            cout << "Enter Title: ";
            getline(cin, title);
            cout << "Enter Author: ";
            getline(cin, author);
            cout << "Enter Genre: ";
            getline(cin, genre);
            cout << "Enter Page Count: ";
            cin >> pageCount;
            {
                // Create a temporary Book object (initially available)
                Book newBook(id, title, author, genre, pageCount, true);
                myLibrary.addBook(newBook);
            }
            break;
                
        case 2: // Remove Book
            cout << "Enter Book ID to remove: ";
            cin >> bookID;
            myLibrary.removeBook(bookID);
            break;
            
        case 3: // Add Member
            cout << "Enter Member ID: ";
            cin >> id;
            cin.ignore(10000, '\n'); 
            cout << "Enter Member Name: ";
            getline(cin, name);
            {
                // Create a temporary Member object
                Member newMember(id, name);
                myLibrary.addMember(newMember);
            }
            break;
            
        case 4: // Remove Member
            cout << "Enter Member ID to remove: ";
            cin >> memberID;
            myLibrary.removeMember(memberID);
            break;
            
        case 5: // Borrow Book
            cout << "Enter Member ID: ";
            cin >> memberID;
            cout << "Enter Book ID to borrow: ";
            cin >> bookID;
            if (myLibrary.borrowBook(memberID, bookID)) 
            {
                cout << "Transaction Successful." << endl;
            }
            break;
            
        case 6: // Return Book
            cout << "Enter Member ID: ";
            cin >> memberID;
            cout << "Enter Book ID to return: ";
            cin >> bookID;
            if (myLibrary.returnBook(memberID, bookID)) 
            {
                cout << "Transaction Successful." << endl;
            }
            break;
            
        case 7: // Search Book by Title
        {
            cout << "Enter Book Title: ";
            cin.ignore(10000, '\n');
            getline(cin, title); // Use getline for titles with spaces
            Book* foundBook = myLibrary.searchBookByTitle(title);
            if (foundBook != nullptr) 
            {
                cout << "\n--- Book Found ---" << endl;
                foundBook->displayBook();
            } 
            else 
            {
                cout << "Book with title '" << title << "' not found." << endl;
            }
            break;
        }
        
        case 8: // Search Book by ID
        {
            cout << "Enter Book ID: ";
            cin >> bookID;
            Book* foundBook = myLibrary.searchBookByID(bookID);
            if (foundBook != nullptr) 
            {
                cout << "\n--- Book Found ---" << endl;
                foundBook->displayBook();
            } 
            else 
            {
                cout << "Book ID " << bookID << " not found." << endl;
            }
            break;
        }
        
        case 9: // Search Member by ID
        {
            cout << "Enter Member ID: ";
            cin >> memberID;
            Member* foundMember = myLibrary.searchMemberByID(memberID);
            if (foundMember != nullptr) 
            {
                cout << "\n--- Member Found ---" << endl;
                // Display details and borrowed books
                foundMember->displayMemberDetails();
                foundMember->displayBorrowedBooks();
            } 
            else 
            {
                cout << "Member ID " << memberID << " not found." << endl;
            }
            break;
        }
        
        case 10: // Display All Available Books
            myLibrary.displayAllAvailableBooks();
            break;
            
        case 11: // Display All Members
            myLibrary.displayAllMembers();
            break;
            
        case 12: // Save Library Data
            cout << "Enter filenames to save (books then members on one line, e.g book.txt member.txt): ";
            cin >> filenameB >> filenameM;
            cout << "Saving data..." << endl;
            success = myLibrary.saveLibraryData(filenameB, filenameM); 
            if (success == false)
            {
                cout << "Failed to save library data to file." << endl;
            }
            else
            {
                cout << "Library data saved to file." << endl;
            }
            break;
            
        case 13: // Load Library Data
            cout << "Enter filenames to load (books then members on one line, e.g book.txt member.txt): ";
            cin >> filenameB >> filenameM;
            cout << "Loading data..." << endl;
            success = myLibrary.loadLibraryData(filenameB, filenameM); 
            if (success == false)
            {
                cout << "Failed to load library data from file." << endl;
            }
            else
            {
                cout << "Library data loaded from file." << endl;
            }
            break;

        case 14: // Assignment Brief Test
            runBriefTest();
            break;

        case 15: // Personal Test
            runPersonalTest();
            break;

        case 16:
            cout << "Exiting the program." << endl;
            break;

        default:
            cout << "Invalid choice. Please try again." << endl;
    }
    }
    while (choice != 16);
}