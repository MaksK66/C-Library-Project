/*
    Member Class Definition file
    member.cpp

    This file contains the implementation of the Member class methods
*/
#include <iostream>
#include <vector>
#include "member.h"
#include "book.h"
using namespace std;

// Definition of the Member class constructor
Member::Member(int id, string n) 
{
    memberID = id;
    name = n;
}
// Definition of the Member class copy constructor
Member::Member(const Member& other) 
{
    memberID = other.memberID;
    name = other.name;
    borrowedBooks = other.borrowedBooks;
}

// Getter methods for the Member class
int Member::getMemberID() const
{
    return memberID;
}
string Member::getName() const
{
    return name;
}
vector<Book> Member::getBorrowedBooks() const
{
    return borrowedBooks;
}
// Setter methods for the Member class
void Member::setMemberID(int id) 
{
    memberID = id;
}
void Member::setName(string n) 
{
    name = n;
}

// Method to borrow a book (Member Class vector)
void Member::borrowBookForMemberVector(Book& book)
{
    borrowedBooks.push_back(book);
}

// Method to return a book (Member Class vector)
void Member::returnBookForMemberVector(int bookID) 
{
    // Error check
    if (borrowedBooks.empty())
    {
        cerr << "Error: No books to return for Member ID: " << memberID << endl;
        return;
    }

    // Iterates through the borrowedBooks vector to find the book with the given bookID
    for (auto it = borrowedBooks.begin(); it != borrowedBooks.end();) 
    {
        // Check if the current book's ID matches the given bookID
        if (it->getBookID() == bookID) 
        {
            it = borrowedBooks.erase(it); // Removes the book from the vector without invalidating the iterator
            break;
        }
        else
        {
            ++it;
        }
    }
}            

// Method to display borrowed books for the member
void Member::displayBorrowedBooks()
{
    cout << "Borrowed Books for Member ID " << memberID << " (" << name << "):" << endl; // Displays member info

    if (borrowedBooks.empty()) 
    {
        cout << "No books currently borrowed." << endl;
        return;
    }
    
    for (const Book& book : borrowedBooks) // Iterate by const reference (no copies, read-only)
    {
        book.displayBook(); // Displays each borrowed book's details
        cout << "------------------------" << endl;
    }
}

// Method to display member details
void Member::displayMemberDetails()
{
    cout << memberID << " " << name; // Prints member ID and name

    if (!borrowedBooks.empty())
    {
        for (const Book& book : borrowedBooks) // Iterate by const reference (no copies, read-only)
        {
            cout << " " << book.getBookID(); // If a book is borrowed, print its ID
        }
    }

    cout << endl;
}